# UniMI Common Tools

This is a combination of many common tools for our UniMI project. However we have designed it to be used accross anywhere. Our initial tooling invloved automated producer and consumer for kafka and connecting and doing CRUD for MongoDB:

<br><br>

**Source**:<br>
https://github.com/binayr/SQUAT

## Create and use whl file

* with and updated setup.py execute the following command to create a whl file,
    ```python setup.py bdist_wheel```

## API

to be updated soon.